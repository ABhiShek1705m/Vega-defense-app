#!/bin/bash
# Install Vega Defense App using local Python 3.10 source
# System Python remains untouched
set -e

# Define paths for the script, Vega wheel, virtual environment, Python source, and local Python installation
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
VEGA_WHL="$SCRIPT_DIR/vega-0.1.0-py3-none-any.whl"
VEGA_ENV="$SCRIPT_DIR/vegaApp"
PYTHON_SRC="$SCRIPT_DIR/Python-3.10.19.tar.xz"
PORTABLE_PYTHON_DIR="$SCRIPT_DIR/portable_python310"

# Detect system architecture
ARCH=$(uname -m)
echo "Detected architecture: $ARCH"

# Install build dependencies needed to compile Python
sudo apt update
sudo apt install -y build-essential wget curl tar \
libffi-dev libssl-dev zlib1g-dev xz-utils \
libbz2-dev liblzma-dev libreadline-dev libsqlite3-dev

# Verify Python source tarball exists
if [ ! -f "$PYTHON_SRC" ]; then
    echo "Error: Python source tarball not found at $PYTHON_SRC"
    exit 1
fi

# Extract Python source to a temporary folder
rm -rf "$SCRIPT_DIR/Python-3.10.19"
tar -xf "$PYTHON_SRC" -C "$SCRIPT_DIR"
cd "$SCRIPT_DIR/Python-3.10.19"

# Compile Python locally into the portable directory
./configure --prefix="$PORTABLE_PYTHON_DIR" --enable-optimizations --with-ensurepip=install
make -j$(nproc)
make install

# Create a virtual environment for Vega using the compiled Python
"$PORTABLE_PYTHON_DIR/bin/python3.10" -m venv "$VEGA_ENV"

# Activate the virtual environment
source "$VEGA_ENV/bin/activate"

# Upgrade pip inside the virtual environment
pip install --upgrade pip

# Install Vega wheel inside the virtual environment
if [ -f "$VEGA_WHL" ]; then
    pip install "$VEGA_WHL"
else
    echo "Error: Vega wheel not found at $VEGA_WHL"
    deactivate
    exit 1
fi

# Grant raw packet capture capability to the venv Python executable
sudo setcap cap_net_raw,cap_net_admin=eip "$PORTABLE_PYTHON_DIR/bin/python3.10"

# Final message with usage instructions
echo "Vega app installation complete!"
echo "Use the virtual environment:"
echo "source $VEGA_ENV/bin/activate"
echo "Register your machine:"
echo "vega register --email Admin@venus.com --password 'yfdga' --ip 10.0.0.172"
echo "Start the server:"
echo "vega-api"

