
# Vega Defense Application

This application has two main functionalities: 
1) Sniffing target environment traffic communication. 
2) Detecting anomalous actions based on the captured traffic packets.

The captured traffic data is processed by a feature extraction process, then sent to the backend and stored in the database.

## Installation

1. Grant the Python interpreter the privilege to capture raw traffic packets (specify the Python binary executable path and version accordingly): 
   ```bash
   sudo setcap cap_net_raw,cap_net_admin=eip /usr/bin/python3.xx
2. Set up an isolated Python environment:
    ```bash
    python3 -m venv vegaApp
3. Start the Python environment:
    ```bash
    source vegaApp/bin/activate
4. Install the Vega app with dependencies:
    ```bash
    pip install vega-0.1.0-py3-none-any.whl
## Usage
1. After installation, run `vega register` to register the target machine. For example (modify each field accordingly, and the IP is the backend server IP): 
   ```bash
   vega register --email Admin@venus.com --password 'j3d$rt+' --ip 10.0.0.172
2. Once the registration is successful and the app IP is provided as an indicator, start the Flask server listening for backend requests by running:
    ```bash
    vega-api
After the server starts, all interactions will be handled from the frontend. At this point, the installation is complete.

## Uninstallation
Uninstallation is triggered from the frontend. After uninstalling the app, it is safe to close the terminal.
 
